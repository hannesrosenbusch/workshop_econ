explanation of dataset

you received a practice dataset with which you can now practice to implement some of the introduced ML models.

your implementations in python code can help you to later build models for your own work.

the dataset has 2722 rows, each representing a US county.

the dataset has about 5000 columns, each representing a county-level variable.

the variables:

GEOID - the FIPS code of the county (can be used to merge in other variables from the internet)

INTPTLAT - latitude of county

INTPTLONG - longitude of county

Percentage_whites - how many white people live in the county (originally the data was used to study intergroup relations)

Percentage_blacks - how many black people live in the county

Median_Income - median income of county residents

Percent_No_HighSchool - percentage of residents without high school degree

Percent_HighSchool_only	- percentage of residents with only a high school degree

Percent_Some_College - percentage of residents with some college experience or an associates degree

Percent_Bachelor_or_higher - percentage of residents with at least a bachelor's degree

crime_per_person - how many crimes committed per person in this county

population_size	- how many residents

Ratio_Employed	- percentage of residents who are employed

percent_democrat_votes2016 - votes for hillary

percent_republican_votes2016 - votes for drumpf

voter_participation - how many voted

sex_ratio - how many men per 100 female residents

median_age - median age of residents

percent_democrat_votes2012 - votes for obama

percent_republican_votes2012 - votes for romney

tblack - average attitude towards black people (high = good)

twhite - average attitude towards white people (high = good)

other variables - prevalence of word (variablename) uttered on Twitter in that county


PICK A DV AND PLAY AROUND
